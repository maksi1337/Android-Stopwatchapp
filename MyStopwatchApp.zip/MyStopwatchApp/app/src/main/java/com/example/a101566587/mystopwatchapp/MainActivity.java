package com.example.a101566587.mystopwatchapp;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

   private int d1;
   private int d2;
   private int d3;
   private int d4;
   private int d5;
   private int d6;
   private int d7;
   private int d8;
   private ImageView digit1;
   private ImageView digit2;
   private ImageView digit3;
   private ImageView digit4;
   private ImageView digit5;
   private ImageView digit6;
   private ImageView digit7;
   private ImageView digit8;
   private Button btnStart;
   private Button btnStop;
   private Button btnNext;
   private Button btnPrev;
   private Button btnReset;
   private Button btnLap;
   private TextView lapDisplayTextView;
   private Button btnPause;
   private boolean btnPauseClicked;

   private Handler handler = new Handler();

   Integer[]greenLedDigits = {R.drawable.greenled0, R.drawable.greenled1,
           R.drawable.greenled2, R.drawable.greenled3,
           R.drawable.greenled4, R.drawable.greenled5,
           R.drawable.greenled6, R.drawable.greenled7,
           R.drawable.greenled8, R.drawable.greenled9};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        d1 = 0;
        d2 = 0;
        d3 = 0;
        d4 = 0;
        d5 = 0;
        d6 = 0;
        d7 = 0;
        d8 = 0;
        digit1 = findViewById(R.id.imageView);
        digit2 = findViewById(R.id.imageView2);
        digit3 = findViewById(R.id.imageView3);
        digit4 = findViewById(R.id.imageView4);
        digit5 = findViewById(R.id.imageView5);
        digit6 = findViewById(R.id.imageView6);
        digit7 = findViewById(R.id.imageView7);
        digit8 = findViewById(R.id.imageView8);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnReset = findViewById(R.id.btnReset);
        btnStop.setEnabled(false);
        btnLap = findViewById(R.id.btnLap);
        lapDisplayTextView = findViewById(R.id.lapDisplayTextView);
        lapDisplayTextView.setMovementMethod(new ScrollingMovementMethod());
        btnPause = findViewById(R.id.btnPause);
        btnPauseClicked = false;


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d1++;

                if (d1 == 10) {
                    d1 = 0;
                    d2++;

                    if (d2 == 10) {
                        d2 = 0;
                        d3++;

                        if (d3 == 10) {
                            d3 = 0;
                            d4++;

                            if (d4 == 6) {
                                d4 = 0;
                                d5++;

                                if (d5 == 10) {
                                    d5 = 0;
                                    d6++;

                                    if (d6 == 6) {
                                        d6 = 0;
                                        d7++;

                                        if (d7 == 3 & d8 == 1){d1 = 0; d2 = 0; d3 = 0; d4 = 0; d5 = 0; d6 = 0; d7 = 0; d8 = 0;}

                                        if (d7 == 10) {
                                            d7 = 0;
                                            d8++;

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                digit1.setImageResource(greenLedDigits[d1]);
                digit2.setImageResource(greenLedDigits[d2]);
                digit3.setImageResource(greenLedDigits[d3]);
                digit4.setImageResource(greenLedDigits[d4]);
                digit5.setImageResource(greenLedDigits[d5]);
                digit6.setImageResource(greenLedDigits[d6]);
                digit7.setImageResource(greenLedDigits[d7]);
                digit8.setImageResource(greenLedDigits[d8]);


            }
        });

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d1--;

                if (d1 == -1 & d2 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d3 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d4 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d5 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d6 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d7 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d8 != 0){d1 = 9; d2--;}
                    else if (d1 == -1 & d2 == 0 & d3 == 0 & d4 == 0 & d5 == 0 & d6 == 0 & d7 == 0 & d8 == 0){d1 = 0;}
                if (d2 == -1 & d3 != 0){d2 = 9; d3--;}
                    else if (d2 == -1 & d4 != 0){d2 = 9; d3--;}
                    else if (d2 == -1 & d5 != 0){d2 = 9; d3--;}
                    else if (d2 == -1 & d6 != 0){d2 = 9; d3--;}
                    else if (d2 == -1 & d7 != 0){d2 = 9; d3--;}
                    else if (d2 == -1 & d8 != 0){d2 = 9; d3--;}
                if (d3 == -1 & d4 != 0){d3 = 9; d4--;}
                    else if (d3 == -1 & d5 != 0){d3 = 9; d4--;}
                    else if (d3 == -1 & d6 != 0){d3 = 9; d4--;}
                    else if (d3 == -1 & d7 != 0){d3 = 9; d4--;}
                    else if (d3 == -1 & d8 != 0){d3 = 9; d4--;}
                if (d4 == -1 & d5 != 0){d4 = 5; d5--;}
                    else if (d4 == -1 & d6 != 0){d4 = 9; d5--;}
                    else if (d4 == -1 & d7 != 0){d4 = 9; d5--;}
                    else if (d4 == -1 & d8 != 0){d4 = 9; d5--;}
                if (d5 == -1 & d6 != 0){d5 = 9; d6--;}
                    else if (d5 == -1 & d7 != 0){d5 = 9; d6--;}
                    else if (d5 == -1 & d8 != 0){d5 = 9; d6--;}
                if (d6 == -1 & d7 != 0){d6 = 5; d7--;}
                    else if (d5 == -1 & d8 != 0){d5 = 9; d6--;}
                if (d7 == -1 & d8 != 0){d7 = 5; d8--;}
                if (d8 == -1){d8 = 0;}

                digit1.setImageResource(greenLedDigits[d1]);
                digit2.setImageResource(greenLedDigits[d2]);
                digit3.setImageResource(greenLedDigits[d3]);
                digit4.setImageResource(greenLedDigits[d4]);
                digit5.setImageResource(greenLedDigits[d5]);
                digit6.setImageResource(greenLedDigits[d6]);
                digit7.setImageResource(greenLedDigits[d7]);
                digit8.setImageResource(greenLedDigits[d8]);
            }
        });

        btnStart.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.post(timeCounter);
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);
            }
        });

        btnStop.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.removeCallbacks(timeCounter);
                btnStart.setEnabled(true);
                btnStop.setEnabled(false);
            }



        });

        btnLap.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                lapDisplayTextView.append("Lap button clicked:" + d8 + d7 + ":" + d6 + d5 + ":" + d4 + d3 + ":" + d2 + d1 + "\n");
                         }

    });

        btnPause.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                btnPauseClicked = true;

            }
        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lapDisplayTextView.setText(null);
                //lapDisplayTextView.append("");
                d1 = 0;
                d2 = 0;
                d3 = 0;
                d4 = 0;
                d5 = 0;
                d6 = 0;
                d7 = 0;
                d8 = 0;
                digit1.setImageResource(greenLedDigits[d1]);
                digit2.setImageResource(greenLedDigits[d2]);
                digit3.setImageResource(greenLedDigits[d3]);
                digit4.setImageResource(greenLedDigits[d4]);
                digit5.setImageResource(greenLedDigits[d5]);
                digit6.setImageResource(greenLedDigits[d6]);
                digit7.setImageResource(greenLedDigits[d7]);
                digit8.setImageResource(greenLedDigits[d8]);
            }
        });

    }
        private Runnable timeCounter = new Runnable() {
            public void run() {
                d1++;

                if (d1 == 10) {
                    d1 = 0;
                    d2++;

                    if (d2 == 10) {
                        d2 = 0;
                        d3++;

                        if (d3 == 10) {
                            d3 = 0;
                            d4++;

                            if (d4 == 6) {
                                d4 = 0;
                                d5++;

                                if (d5 == 10) {
                                    d5 = 0;
                                    d6++;

                                    if (d6 == 6) {
                                        d6 = 0;
                                        d7++;

                                        if (d7 == 3 & d8 == 1){d1 = 0; d2 = 0; d3 = 0; d4 = 0; d5 = 0; d6 = 0; d7 = 0; d8 = 0;}

                                        if(d7 == 10) {
                                            d7 = 0;
                                            d8++;

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                digit1.setImageResource(greenLedDigits[d1]);
                digit2.setImageResource(greenLedDigits[d2]);
                digit3.setImageResource(greenLedDigits[d3]);
                digit4.setImageResource(greenLedDigits[d4]);
                digit5.setImageResource(greenLedDigits[d5]);
                digit6.setImageResource(greenLedDigits[d6]);
                digit7.setImageResource(greenLedDigits[d7]);
                digit8.setImageResource(greenLedDigits[d8]);
                handler.postDelayed(timeCounter, 1);


            }
        };

    }

